package abstractfactory;

public class Pedido {
    private Cafe cafe;
    private suco suco;

    public Pedido(BebidaFactory factory) {
        this.cafe = factory.criarcafe();
        this.suco = factory.criarsuco();
    }
    public void servir() {
        cafe.preparar();
        suco.prerarar();
    }
}

