package abstractfactory.test;

import abstractfactory.BebidaFriaFactory;
import abstractfactory.BebidaQuenteFactory;
import abstractfactory.Pedido;

public class TesteBebida {
    public static void main(String[] args) {
        //BEBIDA QUENTE
        System.out.println("==== Pedido Quente ==== ");
        Pedido quente = new Pedido(new BebidaQuenteFactory());
        quente.servir();
        //Suco e café quente
        System.out.println();

        //BEBIDA FRIA
        System.out.println("=== Pedido Frio ===");
        Pedido frio = new Pedido(new BebidaFriaFactory());
        frio.servir();

        System.out.println();
    }
}