package abstractfactory;

public interface suco {
            void prerarar();
}
