package abstractfactory;

public class SucoQuente implements suco {
    @Override
    public void prerarar() {
        System.out.println("Preparando o chá de laranja quente.");
    }
}
