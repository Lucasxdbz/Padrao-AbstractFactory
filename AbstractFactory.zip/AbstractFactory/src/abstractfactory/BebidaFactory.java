package abstractfactory;

public interface BebidaFactory {
    Cafe criarcafe();
    suco criarsuco();
}

