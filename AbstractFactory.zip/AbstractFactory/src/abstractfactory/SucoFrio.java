package abstractfactory;

public class SucoFrio implements suco {
    @Override
    public void prerarar() {
        System.out.println("Preprando suco de laranja gelado.");
    }
}
