package abstractfactory;

public class BebidaFriaFactory implements BebidaFactory {
    @Override
    public Cafe criarcafe() {return new CafeFrio();}

    @Override
    public suco criarsuco() {return new SucoFrio();}
}
