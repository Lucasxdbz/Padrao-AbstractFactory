package abstractfactory;

public interface Cafe {
            void preparar();
}
