package abstractfactory;

import java.security.PublicKey;

public class BebidaQuenteFactory implements BebidaFactory {
    @Override
    public Cafe criarcafe() { return new CafeFrio();}

    @Override
    public suco criarsuco() { return new SucoFrio();}
}
