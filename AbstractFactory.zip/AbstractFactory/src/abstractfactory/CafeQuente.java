package abstractfactory;

public class CafeQuente implements Cafe {
    @Override
    public void preparar() {
        System.out.println("Preparando o café quente.");
    }
}
