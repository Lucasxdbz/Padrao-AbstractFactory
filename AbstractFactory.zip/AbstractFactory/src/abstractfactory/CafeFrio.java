package abstractfactory;

public class CafeFrio implements Cafe {
    @Override
    public void preparar() {
        System.out.println("Preparando o Café Frio.");
    }
}
